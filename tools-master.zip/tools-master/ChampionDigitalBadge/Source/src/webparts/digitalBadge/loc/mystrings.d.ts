declare interface IDigitalBadgeWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DigitalBadgeWebPartStrings' {
  const strings: IDigitalBadgeWebPartStrings;
  export = strings;
}
