import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IClbHomeProps {
  context: WebPartContext;
  description: string;
  siteUrl: string;
}
