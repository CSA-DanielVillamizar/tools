declare interface IClbHomeWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ClbHomeWebPartStrings' {
  const strings: IClbHomeWebPartStrings;
  export = strings;
}
