export default interface IProfileImage {
  url: string;
  width: number;
}
