# Get Started App
Demonstration app for M365 Learning Pathways or other SharePoint site integration into Microsoft Teams.  View the ReadMe file for installation instructions

# Questions and Issues

For questions or issues please file an issue within this repo and our team and the community will respond as we are available.  This repo does not have a response SLA. 

# Open Source

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/). For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

# Disclaimer
THIS CODE IS PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
