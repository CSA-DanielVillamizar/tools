export const Announcement_Title = "Announcements";
export const WorkingNow_Title = "Working Now";
export const NewTeamMembers_Title = "New Team Members";
export const Task_Title = "Tasks";
export const News_Title = "News";
export const Key_Title = "Key Metrics";
