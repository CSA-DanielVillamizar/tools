
const apiendpoint="{{apiendpoint}}";
export const AnnouncementAdaptiveCardDetails =
  `${apiendpoint}samplehub/AnnouncementAdaptiveCardDetails`;
export const TeamsConfig =
  `${apiendpoint}samplehub/TeamsConfig`;
export const NewsData =`${apiendpoint}samplehub/NewsData`;
export const TeamMemberDetails =`${apiendpoint}samplehub/TeamMemberDetails`;
export const TeamMember_Link1 =
"{Metnion team member link}";
export const TeamMember_Link2 =
"{Metnion second team member link}";
export const GetUserAccessToken =
`${apiendpoint}samplehub/GetUserAccessToken`;
export const Announcements_TeamsLink =
"{Mention compnay communicator app tempalte link}";
export const Announcements_TeamsLink_1 =
`${apiendpoint}samplehub/AnnouncementAdaptiveCardDetails`;
export const WorkingNow_Link = "https://teams.microsoft.com/l/chat/0/0?users=";
export const Task_Link1 = "https://graph.microsoft.com/v1.0/me/planner/tasks";
export const Task_Link2 =
  `https://teams.microsoft.com/l/entity/`;
export const Task_Link3 =
  `https://teams.microsoft.com/l/entity/`;
export const Learning_Link1 = 
"{Mention your learning app link}";
export const Learning_Link2 =
"{Mention your learning app link}";
export const Learning_Link3 =
"{Mention your learning app link}";
